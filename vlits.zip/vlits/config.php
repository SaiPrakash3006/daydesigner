<?php
    $con=mysqli_connect("localhost","root","","vlits") or die("unable to connect");
?>