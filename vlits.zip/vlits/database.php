<?php
$host="localhost";
$user="root";
$pass="";
$dbname="vlits";

$conn=mysqli_connect($host, $user, $pass, $dbname);



?>